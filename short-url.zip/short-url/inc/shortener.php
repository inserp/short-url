<?php

class Shortener
{
    private $redirect;
    private $url;
    private $count;

    public function __construct()
    {
        $this->redirect = get_field( 'full_url_to_redirect' );
        $this->url = get_post_permalink( get_the_ID() );
        $this->count = intval(get_field( 'redirects') ) + 1;
    }

    // Redirect by itself
    // TODO: remove the initial redirect for URL with CPT slug to prevent double redirection.
    public function redirections()
    {
        if( !empty( $this->redirect ) && filter_var( $this->redirect, FILTER_VALIDATE_URL ) ) {
            update_field( 'redirects', $this->count );
            wp_redirect( $this->redirect, 301 );
            exit();
        }
    }

}

?>