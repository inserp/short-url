<?php

// Add ACF JSON
function su_acf_json_load_point( $paths ) {
    $paths[] = SU_DIR_PATH . '/acf-json';
    return $paths;
}
add_filter('acf/settings/load_json', 'su_acf_json_load_point', 999);

// Checking current page post type and initiate the redirection
function shortener_template_redirect() {
	
	if( SU === get_post_type() ) {
        $suObj = Shortener::get_instance();
        $suObj->redirections();
    }

}
add_action( 'template_redirect', 'shortener_template_redirect' );

// Custom columns view on the admin table list
function su_manage_columns ( $columns ) {
    $new_columns = [
        'cb' => '<input type="checkbox" />',
        'title' => __( 'Title', 'short-url' ),
        'url' => __( 'Short URL', 'short-url' ),
        'redirect_url' => __( 'Redirect', 'short-url' ),
        'date' => __( 'Date', 'short-url' ),
        'redirects' => __( 'Clicks', 'short-url' )
    ];
    return $new_columns;
}
add_filter( 'manage_su_posts_columns', 'su_manage_columns' );

function su_manage_columns_values ( $name  ) {
    if ( $name === 'redirects' ) {
        echo get_field( 'redirects', get_the_ID() );
    }
    if ( $name === 'redirect_url' ) {
        echo get_field( 'full_url_to_redirect', get_the_ID() );
    }
    if ( $name === 'url' ) {
        $permalink = get_permalink();
        $permalink_301 = str_replace( '/' . SU . '/', '/', $permalink);
        echo '<a href="'.$permalink.'" target="_blank">'.$permalink.'</a><br><a href="'.$permalink_301.'" target="_blank">'.$permalink_301.'</a>';
    }
}
add_action( 'manage_su_posts_custom_column', 'su_manage_columns_values' );


function su_register_sortable_columns( $columns ) {
    $columns['redirects'] = __( 'Clicks', 'short-url' );
    $columns['redirect_url'] = __( 'Redirect', 'short-url' );
    return $columns;
}
add_filter( 'manage_edit-su_sortable_columns', 'su_register_sortable_columns' );

function su_views_columns_orderby( $vars ) {
    if ( isset( $vars['orderby'] ) ) {
        switch ($vars['orderby'] ){
            case "Clicks" :
                $vars = array_merge( $vars, [
                    'meta_key' => 'redirects',
                    'orderby'  => 'meta_value_num',
                ] );
            break ;
            case "Redirect" :
                $vars = array_merge( $vars, [
                    'meta_key' => 'full_url_to_redirect',
                    'orderby'  => 'meta_value',
                ] );
            break ;
        }
    }
    return $vars;
}
add_filter( 'request', 'su_views_columns_orderby' );

function su_row_actions( $actions, $post ) {
    if ( SU === $post->post_type ) {
        unset( $actions['inline hide-if-no-js'] );
        unset( $actions['view'] );
    }
    return $actions;
}
add_filter( 'post_row_actions', 'su_row_actions', 10, 2 );


// Custom role functional
function add_url_manager_role(){
    add_role( SU_ROLE, __( 'URL Shortener Manager', 'short-url' ), [
        'read' => true
    ]);
}
add_action( 'admin_init', 'add_url_manager_role', 1 ); 


function add_url_manager_role_caps() {
    $roles_to_update_cups = ['administrator', SU_ROLE];
    foreach($roles_to_update_cups as $current_role){
        $role = get_role( $current_role );  
        $role->add_cap( 'edit_' . SUS );
        $role->add_cap( 'edit_others_' . SUS );
        $role->add_cap( 'edit_private_' . SUS );
        $role->add_cap( 'edit_published_' . SUS );
        $role->add_cap( 'publish_' . SUS );
        $role->add_cap( 'delete_' . SUS );
        $role->add_cap( 'delete_others_' . SUS );
        $role->add_cap( 'delete_published_' . SUS ); 
        $role->add_cap( 'delete_private_' . SUS ); 
    }
}

add_action( 'admin_init','add_url_manager_role_caps', 999 );

// Debugging function
function su_debug($item, $text = ''){
	if(!empty($text)) $text = $text . "\n";
    file_put_contents( SU_DIR_PATH . '/debug.log', "\n" . $text, FILE_APPEND);
    file_put_contents( SU_DIR_PATH . '/debug.log', print_r($item, true), FILE_APPEND);
}


?>