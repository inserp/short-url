<?php
/**
 * Plugin Name:     URL shortener
 * Plugin URI:      https://www.linkedin.com/in/ihar-dounar/
 * Description:     URL shortener functions.
 * Author:          Ihar Dounar
 * Author URI:      https://www.linkedin.com/in/ihar-dounar/
 * Text Domain:     short-url
 * Version:         1.0.0
 *
 * @package         short-url
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/*************************************************************************
* Constants
************************************************************************/
define( 'SU_DIR_PATH', __DIR__ );
define( 'SU_DIR_URL', plugin_dir_url(__FILE__) );
define( 'SU', 'su' );
define( 'SUS', 'sus' );
define( 'SU_ROLE', 'url_editor' );
define( 'SU_TXT', 'short-url' );


/*************************************************************************
 * Requires - core
 ************************************************************************/
//Register ACF


/*************************************************************************
 * Public - Extra functions
 ************************************************************************/
//Add extra functions
require_once SU_DIR_PATH . '/inc/actions.php';
require_once SU_DIR_PATH . '/inc/shortener.php';